### Relações e Grafos

### Limpando Plots, Console and Ambiente
rm(list = ls())
dev.off(dev.list()["RStudioGD"])
cat("\014")

#install.packages("igraph")
library(igraph) # carregando pacote

# Primeiro grafo
g1 <- graph( edges=c(1,2, 2,3, 3, 1), n=3, directed=F)
plot(g1)

# Grafo com relações entre pessoas
g4 <- graph( c("John", "Jim", "Jim", "Jack", "Jim", "Jack", "John",
               "John"), isolates=c("Jesse", "Janis", "Jennifer", "Justin") )

plot(g4, edge.arrow.size=.5, vertex.color="gold", vertex.size=15,
     vertex.frame.color="gray", vertex.label.color="black",
     vertex.label.cex=0.8, vertex.label.dist=2, edge.curved=0.2)


# Visualizando relações 
tr <- make_tree(40, children = 3, mode = "undirected")
plot(tr, vertex.size=10, vertex.label=NA)

# Clude de Karate
zach <- graph("Zachary") # the Zachary carate club
plot(zach, vertex.size=10, vertex.label=NA)
