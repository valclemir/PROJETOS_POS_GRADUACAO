### Conexões de Voos

### Limpando Plots, Console and Ambiente
rm(list = ls())
dev.off(dev.list()["RStudioGD"])
cat("\014")

#install.packages("maps")
#install.packages("geosphere")
#install.packages("dplyr")
#install.packages("nycflights13")

library(maps) #Projeção de mapas
library(geosphere) # geo-coordinates
library(dplyr) # manipulação de dados
library(nycflights13) # voos de NY

usairports <- filter(airports, lat < 48.5)
usairports <- filter(usairports, lon > -130)
usairports <- filter(usairports, faa!="JFK")
jfk <- filter(airports, faa=="JFK")

map("world", regions=c("usa"), fill=T, col="grey8", bg="grey15",
    ylim=c(21.0,50.0), xlim=c(-130.0,-65.0))

for (i in (1:dim(usairports)[1])) {
  inter <- gcIntermediate(c(jfk$lon[1], jfk$lat[1]), c(usairports$lon[i],
                                                       usairports$lat[i]), n=200) # way points of 2 locations
  lines(inter, lwd=0.1, col="turquoise2") # coordinates
}

points(usairports$lon,usairports$lat, pch=3, cex=0.1, col="chocolate1")


  